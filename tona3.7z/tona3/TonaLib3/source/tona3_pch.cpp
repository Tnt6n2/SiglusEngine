#include	"tona3_pch.h"

// ****************************************************************
// �e�X�g�p�t���O
// ================================================================
int		G_test0 = 0;
int		G_test1 = 0;
int		G_test2 = 0;
int		G_test3 = 0;
int		G_test4 = 0;
int		G_test5 = 0;
int		G_test6 = 0;
int		G_test7 = 0;
int		G_test8 = 0;
int		G_test9 = 0;
