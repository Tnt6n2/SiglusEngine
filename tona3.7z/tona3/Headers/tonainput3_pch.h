#include	"tona3.h"

#include	<dinput.h>