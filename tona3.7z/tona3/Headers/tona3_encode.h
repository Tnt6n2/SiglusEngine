#pragma		once

// ****************************************************************
// �^�C���R�s�[
// ================================================================
void tile_copy(BYTE *d_buf, BYTE *s_buf, int buf_xl, int buf_yl, BYTE *tile, int t_xl, int t_yl, int t_repx, int t_repy, int t_reverse, BYTE t_limit);

