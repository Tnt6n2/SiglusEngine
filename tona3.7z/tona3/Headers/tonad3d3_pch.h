#include	"tona3.h"
#include	"tonagraphic3.h"

#include	<d3dx9.h>