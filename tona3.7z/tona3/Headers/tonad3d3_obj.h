#pragma		once


namespace NT3
{

}

