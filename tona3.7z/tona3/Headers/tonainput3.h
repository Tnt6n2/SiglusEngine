
#include	"tonainput3_pch.h"
#include	"tonainput3_dinput.h"

#ifdef _DEBUG
	#pragma		comment(lib,"TonaInput3_d.lib")
#else
	#pragma		comment(lib,"TonaInput3.lib")
#endif