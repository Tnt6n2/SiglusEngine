
#include	"tonad3d3_pch.h"
#include	"tonad3d3_d3d.h"
#include	"tonad3d3_state.h"
#include	"tonad3d3_data.h"
#include	"tonad3d3_surface.h"
#include	"tonad3d3_texture.h"
#include	"tonad3d3_album.h"
#include	"tonad3d3_effect.h"
#include	"tonad3d3_sprite.h"
#include	"tonad3d3_mask.h"
//#include	"tonad3d3_view.h"

#include	"tonad3d3_debug_text.h"
#include	"tonad3d3_camera.h"
#include	"tonad3d3_light_manager.h"
#include	"tonad3d3_renderer.h"

#ifdef _DEBUG
	#pragma		comment(lib,"TonaD3D3_d.lib")
#else
	#pragma		comment(lib,"TonaD3d3.lib")
#endif
