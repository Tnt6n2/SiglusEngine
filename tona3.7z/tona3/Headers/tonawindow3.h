
#include	"tona3.h"

#include	"tonawindow3_wbase.h"
#include	"tonawindow3_window.h"
#include	"tonawindow3_control.h"
#include	"tonawindow3_listview.h"
#include	"tonawindow3_dialog.h"
#include	"tonawindow3_dialog_separater.h"
#include	"tonawindow3_dialog_statusbar.h"
#include	"tonawindow3_menu.h"

#ifdef _DEBUG
	#pragma		comment(lib,"TonaWindow3_d.lib")
#else
	#pragma		comment(lib,"TonaWindow3.lib")
#endif
