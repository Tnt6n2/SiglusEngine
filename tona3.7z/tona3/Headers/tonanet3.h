
#include	"tonanet3_pch.h"
#include	"tonanet3_network.h"

#ifdef _DEBUG
	#pragma		comment(lib,"TonaNet3_d.lib")
#else
	#pragma		comment(lib,"TonaNet3.lib")
#endif
