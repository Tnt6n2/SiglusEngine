#pragma once



namespace NT3
{


class C_d3d_view;




















}