#pragma		once

// ****************************************************************
// �C���N���[�h
// ================================================================
#include	"namalib_sys_main.h"
#include	"namalib_sys_text_analyze.h"
#include	"namalib_sys_text_format.h"
#include	"namalib_sys_dialog_template.h"
#include	"namalib_sys_int_window.h"

// ****************************************************************
// ���C�u����
// ================================================================
#ifdef _DEBUG
	#pragma		comment(lib,"namalib_sys_d.lib")
#else
	#pragma		comment(lib,"namalib_sys.lib")
#endif

