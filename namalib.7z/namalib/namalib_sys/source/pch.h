#pragma		once

#include	"tona3.h"
#include	"tonawindow3.h"

using namespace NT3;

#include	"namalib_sys_main.h"

using namespace Nnama;
