#pragma		once

#include	<windows.h>

#include	"namalib_grp.h"

#include	"namalib_grp_macro_basic.h"

#include	"namalib_grp_macro_draw_tcgd_std.h"
#include	"namalib_grp_macro_draw_tcgd_add.h"
#include	"namalib_grp_macro_draw_tcgd_sub.h"
#include	"namalib_grp_macro_draw_tcgd_rsub.h"
#include	"namalib_grp_macro_draw_tcgd_flt.h"
#include	"namalib_grp_macro_draw_tcgd_mul.h"
#include	"namalib_grp_macro_draw_tcgd_bld.h"

#include	"namalib_grp_macro_proc.h"

#include	"namalib_grp_macro_proc_stdgrp.h"
#include	"namalib_grp_macro_proc_stdbox.h"
#include	"namalib_grp_macro_proc_lbdgrp.h"
#include	"namalib_grp_macro_proc_lbdbox.h"
#include	"namalib_grp_macro_proc_lined.h"

#include	"namalib_grp_macro_proc_chgstdbox.h"
#include	"namalib_grp_macro_proc_chglbdbox.h"
#include	"namalib_grp_macro_proc_chglined.h"

#include	"namalib_grp_macro_proc_bldstdgrp.h"
#include	"namalib_grp_macro_proc_bldstdbox.h"
#include	"namalib_grp_macro_proc_bldlbdgrp.h"
#include	"namalib_grp_macro_proc_bldlbdbox.h"
#include	"namalib_grp_macro_proc_bldlined.h"
