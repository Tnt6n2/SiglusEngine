#pragma		once

#include	<windows.h>
#include	<math.h>
#include	<vector>
#include	"namalib_grp.h"
