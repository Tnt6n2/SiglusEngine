#include	"namalib_grp_pch.h"

// �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_NORMAL
		__END_LBDGRP_NORMAL
	}
}

// �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_TR
		__END_LBDGRP_SPRITE
	}
}

// ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// �ϐF �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_COLOR
		__END_LBDGRP_NORMAL
	}
}

// �ϐF �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_COLOR_TR
		__END_LBDGRP_SPRITE
	}
}

// �ϐF ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_COLOR_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// �ϐF ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_COLOR_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// �ϐF �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_COLOR_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// �ϐF �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_COLOR_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// �ϐF �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// �ϐF �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_color_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���] �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_REVERSE
		__END_LBDGRP_NORMAL
	}
}

// ���] �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_REVERSE_TR
		__END_LBDGRP_SPRITE
	}
}

// ���] ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_REVERSE_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���] ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_REVERSE_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���] �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_REVERSE_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���] �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_REVERSE_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���] �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_REVERSE_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���] �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_REVERSE_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���] �ϐF �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_REVERSE_COLOR
		__END_LBDGRP_NORMAL
	}
}

// ���] �ϐF �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_REVERSE_COLOR_TR
		__END_LBDGRP_SPRITE
	}
}

// ���] �ϐF ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_REVERSE_COLOR_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���] �ϐF ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_REVERSE_COLOR_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���] �ϐF �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_REVERSE_COLOR_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���] �ϐF �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���] �ϐF �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���] �ϐF �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_reverse_color_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO
		__END_LBDGRP_NORMAL
	}
}

// ���m �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���m �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m �ϐF �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_COLOR
		__END_LBDGRP_NORMAL
	}
}

// ���m �ϐF �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_COLOR_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m �ϐF ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_COLOR_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m �ϐF ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_COLOR_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m �ϐF �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_COLOR_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���m �ϐF �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_COLOR_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m �ϐF �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m �ϐF �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_color_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m ���] �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_REVERSE
		__END_LBDGRP_NORMAL
	}
}

// ���m ���] �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_REVERSE_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m ���] ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_REVERSE_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m ���] ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_REVERSE_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m ���] �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_REVERSE_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���m ���] �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_REVERSE_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m ���] �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_REVERSE_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m ���] �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_REVERSE_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m ���] �ϐF �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_REVERSE_COLOR
		__END_LBDGRP_NORMAL
	}
}

// ���m ���] �ϐF �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_REVERSE_COLOR_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m ���] �ϐF ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_REVERSE_COLOR_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m ���] �ϐF ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_REVERSE_COLOR_TR
		__END_LBDGRP_TR_SPRITE
	}
}

// ���m ���] �ϐF �F�� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_bright_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_NORMAL
		__DRAW_RSUB_MONO_REVERSE_COLOR_BRIGHT
		__END_LBDGRP_NORMAL
	}
}

// ���m ���] �ϐF �F�� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_bright_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_SPRITE
		__DRAW_RSUB_MONO_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_SPRITE
	}
}

// ���m ���] �ϐF �F�� ���� �ʏ�
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_bright_tr_normal(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_NORMAL
		__DRAW_RSUB_MONO_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_NORMAL
	}
}

// ���m ���] �ϐF �F�� ���� �X�v���C�g
void Cnamalib_grp::_tcgd_func_lbdgrp_rsub_mono_reverse_color_bright_tr_sprite(void)
{
	__PARAM_LOCAL_COPY_LBDP
	_asm{
		__START_LBDGRP_TR_SPRITE
		__DRAW_RSUB_MONO_REVERSE_COLOR_BRIGHT_TR
		__END_LBDGRP_TR_SPRITE
	}
}

