#define	system_liblary_nolink			1
#include	"sys.h"
#include	"pch.h"
